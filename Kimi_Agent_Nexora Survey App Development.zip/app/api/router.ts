import { authRouter } from "./auth-router";
import { customAuthRouter } from "./custom-auth-router";
import { surveyRouter } from "./survey-router";
import { sessionRouter } from "./session-router";
import { adminRouter } from "./admin-router";
import { payoutRouter } from "./payout-router";
import { publicRouter } from "./public-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  customAuth: customAuthRouter,
  survey: surveyRouter,
  session: sessionRouter,
  admin: adminRouter,
  payout: payoutRouter,
  public: publicRouter,
});

export type AppRouter = typeof appRouter;
