import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";
import { eq, and } from "drizzle-orm";

export const payoutRouter = createRouter({
  // Request a payout
  request: authedQuery
    .input(z.object({ amount: z.number().min(0) }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userId = ctx.user.id;

      // Check system status
      const settings = await db.select().from(schema.systemSettings).limit(1);
      if (settings.length === 0 || settings[0].systemStatus === "OFF") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "System is currently OFF",
        });
      }

      // Get user's available earnings
      const user = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, userId))
        .limit(1);

      if (user.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
      }

      const totalEarnings = Number(user[0].totalEarnings);
      const threshold = settings.length > 0 ? Number(settings[0].payoutThreshold) : 25;

      if (totalEarnings < threshold) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `Minimum payout threshold is $${threshold}`,
        });
      }

      if (input.amount > totalEarnings) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Insufficient earnings",
        });
      }

      // Check for existing pending payout
      const pending = await db
        .select()
        .from(schema.payouts)
        .where(
          and(
            eq(schema.payouts.userId, userId),
            eq(schema.payouts.status, "pending")
          )
        )
        .limit(1);

      if (pending.length > 0) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "You already have a pending payout request",
        });
      }

      await db.insert(schema.payouts).values({
        userId,
        amount: input.amount.toFixed(2),
        status: "pending",
        requestedAt: new Date(),
      });

      return { success: true };
    }),

  // Get user's payouts
  getMine: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const payouts = await db
      .select()
      .from(schema.payouts)
      .where(eq(schema.payouts.userId, ctx.user.id))
      .orderBy(schema.payouts.requestedAt);

    return payouts;
  }),

  // Get all payouts (admin)
  getAll: adminQuery.query(async () => {
    const db = getDb();
    const payouts = await db
      .select({
        payout: schema.payouts,
        userName: schema.users.name,
        userEmail: schema.users.email,
      })
      .from(schema.payouts)
      .leftJoin(schema.users, eq(schema.payouts.userId, schema.users.id))
      .orderBy(schema.payouts.requestedAt);

    return payouts;
  }),

  // Approve payout (admin)
  approve: adminQuery
    .input(z.object({ payoutId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const payout = await db
        .select()
        .from(schema.payouts)
        .where(eq(schema.payouts.id, input.payoutId))
        .limit(1);

      if (payout.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Payout not found" });
      }

      if (payout[0].status !== "pending") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Payout is not pending",
        });
      }

      await db
        .update(schema.payouts)
        .set({
          status: "approved",
          processedAt: new Date(),
        })
        .where(eq(schema.payouts.id, input.payoutId));

      return { success: true };
    }),

  // Mark as paid (admin)
  markPaid: adminQuery
    .input(z.object({ payoutId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      await db
        .update(schema.payouts)
        .set({
          status: "paid",
          processedAt: new Date(),
        })
        .where(eq(schema.payouts.id, input.payoutId));

      return { success: true };
    }),

  // Reject payout (admin)
  reject: adminQuery
    .input(z.object({ payoutId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      await db
        .update(schema.payouts)
        .set({
          status: "rejected",
          processedAt: new Date(),
        })
        .where(eq(schema.payouts.id, input.payoutId));

      return { success: true };
    }),
});
