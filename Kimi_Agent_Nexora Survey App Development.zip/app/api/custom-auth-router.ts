import { z } from "zod";
import bcrypt from "bcryptjs";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";
import { eq } from "drizzle-orm";
import { signCustomToken, COOKIE_NAME } from "./custom-auth";
import { env } from "./lib/env";
import * as cookie from "cookie";

function generateVerificationToken() {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

export const customAuthRouter = createRouter({
  register: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        email: z.string().email(),
        password: z.string().min(6).max(255),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Check if email already exists
      const existing = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.email, input.email))
        .limit(1);

      if (existing.length > 0) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "Email already registered",
        });
      }

      const hashedPassword = await bcrypt.hash(input.password, 10);
      const verificationToken = generateVerificationToken();

      const result = await db.insert(schema.users).values({
        name: input.name,
        email: input.email,
        password: hashedPassword,
        isVerified: false,
        verificationToken,
        role: "user",
        isBanned: false,
        totalHoursWorked: "0.00",
        totalEarnings: "0.00",
      });

      // In production, send email with verification link
      // For now, return the token so user can verify
      const userId = Number(result[0].insertId);

      return {
        success: true,
        message: "Registration successful. Please verify your email.",
        verificationToken, // In production, don't return this - send via email
        userId,
      };
    }),

  verifyEmail: publicQuery
    .input(
      z.object({
        email: z.string().email(),
        token: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const user = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.email, input.email))
        .limit(1);

      if (user.length === 0) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "User not found",
        });
      }

      if (user[0].isVerified) {
        return { success: true, message: "Email already verified" };
      }

      if (user[0].verificationToken !== input.token) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Invalid verification token",
        });
      }

      await db
        .update(schema.users)
        .set({ isVerified: true, verificationToken: null })
        .where(eq(schema.users.id, user[0].id));

      return { success: true, message: "Email verified successfully" };
    }),

  login: publicQuery
    .input(
      z.object({
        email: z.string().email(),
        password: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();

      const user = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.email, input.email))
        .limit(1);

      if (user.length === 0) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid email or password",
        });
      }

      const u = user[0];

      if (!u.isVerified) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Please verify your email before logging in",
        });
      }

      if (u.isBanned) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Your account has been banned",
        });
      }

      if (!u.password) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid email or password",
        });
      }

      const valid = await bcrypt.compare(input.password, u.password);
      if (!valid) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid email or password",
        });
      }

      const token = await signCustomToken({ userId: u.id, email: u.email || "" });

      // Set cookie
      const cookieOpts = {
        httpOnly: true,
        path: "/",
        sameSite: "lax" as const,
        secure: env.isProduction,
        maxAge: 7 * 24 * 60 * 60,
      };

      ctx.resHeaders.append(
        "set-cookie",
        cookie.serialize(COOKIE_NAME, token, cookieOpts)
      );

      return {
        success: true,
        user: {
          id: u.id,
          name: u.name,
          email: u.email,
          role: u.role,
          isVerified: u.isVerified,
          totalHoursWorked: u.totalHoursWorked,
          totalEarnings: u.totalEarnings,
        },
      };
    }),

  me: authedQuery.query((opts) => {
    const u = opts.ctx.user;
    return {
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      isVerified: u.isVerified,
      isBanned: u.isBanned,
      totalHoursWorked: u.totalHoursWorked,
      totalEarnings: u.totalEarnings,
      createdAt: u.createdAt,
    };
  }),

  logout: authedQuery.mutation(async ({ ctx }) => {
    const cookieOpts = {
      httpOnly: true,
      path: "/",
      sameSite: "lax" as const,
      secure: env.isProduction,
      maxAge: 0,
    };

    ctx.resHeaders.append(
      "set-cookie",
      cookie.serialize(COOKIE_NAME, "", cookieOpts)
    );

    return { success: true };
  }),
});
