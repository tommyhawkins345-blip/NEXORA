import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";
import { eq } from "drizzle-orm";

export const surveyRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const allSurveys = await db
      .select()
      .from(schema.surveys)
      .where(eq(schema.surveys.isActive, true));
    return allSurveys;
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const survey = await db
        .select()
        .from(schema.surveys)
        .where(eq(schema.surveys.id, input.id))
        .limit(1);
      return survey.at(0) ?? null;
    }),

  create: adminQuery
    .input(
      z.object({
        title: z.string().min(1).max(255),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(schema.surveys).values({
        title: input.title,
        description: input.description,
        isActive: true,
      });
      return { success: true, id: Number(result[0].insertId) };
    }),

  update: adminQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).max(255).optional(),
        description: z.string().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const updateData: Partial<schema.InsertSurvey> = {};
      if (input.title) updateData.title = input.title;
      if (input.description !== undefined) updateData.description = input.description;
      if (input.isActive !== undefined) updateData.isActive = input.isActive;

      await db
        .update(schema.surveys)
        .set(updateData)
        .where(eq(schema.surveys.id, input.id));

      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(schema.surveys).where(eq(schema.surveys.id, input.id));
      return { success: true };
    }),
});
