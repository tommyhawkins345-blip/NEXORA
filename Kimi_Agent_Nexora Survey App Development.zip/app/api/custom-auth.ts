import * as jose from "jose";
import { env } from "./lib/env";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";
import { eq } from "drizzle-orm";

const JWT_SECRET = new TextEncoder().encode(env.jwtSecret);
const COOKIE_NAME = "nexora_session";

export async function signCustomToken(payload: { userId: number; email: string }) {
  return new jose.SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(JWT_SECRET);
}

export async function verifyCustomToken(token: string) {
  try {
    const { payload } = await jose.jwtVerify(token, JWT_SECRET, {
      clockTolerance: 60,
    });
    return payload as { userId: number; email: string };
  } catch {
    return null;
  }
}

export async function authenticateCustomRequest(headers: Headers) {
  const cookieHeader = headers.get("cookie") || "";
  const cookies = Object.fromEntries(
    cookieHeader.split(";").map((c) => {
      const [key, ...val] = c.trim().split("=");
      return [key, val.join("=")];
    })
  );

  const token = cookies[COOKIE_NAME];
  if (!token) return null;

  const claim = await verifyCustomToken(token);
  if (!claim) return null;

  const db = getDb();
  const rows = await db
    .select()
    .from(schema.users)
    .where(eq(schema.users.id, claim.userId))
    .limit(1);

  return rows.at(0) ?? null;
}

export { COOKIE_NAME };
