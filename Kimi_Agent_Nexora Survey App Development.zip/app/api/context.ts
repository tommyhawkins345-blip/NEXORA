import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import type { User } from "@db/schema";
import { authenticateRequest } from "./kimi/auth";
import { authenticateCustomRequest } from "./custom-auth";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: User;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const ctx: TrpcContext = { req: opts.req, resHeaders: opts.resHeaders };
  try {
    // Try custom auth first
    const customUser = await authenticateCustomRequest(opts.req.headers);
    if (customUser) {
      ctx.user = customUser;
    }
  } catch {
    // ignore
  }
  
  if (!ctx.user) {
    try {
      // Fallback to OAuth
      ctx.user = await authenticateRequest(opts.req.headers);
    } catch {
      // Authentication is optional here
    }
  }
  return ctx;
}
