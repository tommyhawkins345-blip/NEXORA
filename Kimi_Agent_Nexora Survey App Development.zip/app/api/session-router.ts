import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";
import { eq, and, gte, sql } from "drizzle-orm";

export const sessionRouter = createRouter({
  // Start a survey session
  start: authedQuery
    .input(z.object({ surveyId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userId = ctx.user.id;

      // Check system status
      const settings = await db.select().from(schema.systemSettings).limit(1);
      if (settings.length === 0 || settings[0].systemStatus === "OFF") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "System is currently OFF. Please try again later.",
        });
      }

      // Check if user has an active session
      const activeSessions = await db
        .select()
        .from(schema.surveySessions)
        .where(
          and(
            eq(schema.surveySessions.userId, userId),
            eq(schema.surveySessions.status, "active")
          )
        )
        .limit(1);

      if (activeSessions.length > 0) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "You already have an active session",
        });
      }

      // Check daily hours limit
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todaySessions = await db
        .select()
        .from(schema.surveySessions)
        .where(
          and(
            eq(schema.surveySessions.userId, userId),
            gte(schema.surveySessions.startTime, today)
          )
        );

      const dailyHours = todaySessions.reduce((sum, s) => {
        return sum + (Number(s.approvedHours) || 0);
      }, 0);

      const maxDaily = Number(settings[0].maxDailyHours);
      if (dailyHours >= maxDaily) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `Daily limit of ${maxDaily} hours reached`,
        });
      }

      // Check if survey exists and is active
      const survey = await db
        .select()
        .from(schema.surveys)
        .where(eq(schema.surveys.id, input.surveyId))
        .limit(1);

      if (survey.length === 0 || !survey[0].isActive) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Survey not found or inactive",
        });
      }

      const result = await db.insert(schema.surveySessions).values({
        userId,
        surveyId: input.surveyId,
        startTime: new Date(),
        duration: 0,
        activeTime: 0,
        status: "active",
      });

      const sessionId = Number(result[0].insertId);

      return {
        success: true,
        sessionId,
        startTime: new Date(),
      };
    }),

  // Stop a session (user submits)
  stop: authedQuery
    .input(
      z.object({
        sessionId: z.number(),
        finalDuration: z.number().min(0), // seconds
        finalActiveTime: z.number().min(0), // seconds
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userId = ctx.user.id;

      const session = await db
        .select()
        .from(schema.surveySessions)
        .where(eq(schema.surveySessions.id, input.sessionId))
        .limit(1);

      if (session.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Session not found" });
      }

      const s = session[0];
      if (s.userId !== userId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not your session" });
      }

      if (s.status !== "active") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Session is not active",
        });
      }

      // Calculate hours from active time
      const activeHours = input.finalActiveTime / 3600;
      const settings = await db.select().from(schema.systemSettings).limit(1);
      const hourlyRate = settings.length > 0 ? Number(settings[0].hourlyRate) : 5;
      const earnings = (activeHours * hourlyRate).toFixed(2);

      await db
        .update(schema.surveySessions)
        .set({
          endTime: new Date(),
          duration: input.finalDuration,
          activeTime: input.finalActiveTime,
          status: "submitted",
          approvedHours: activeHours.toFixed(2),
          earnings,
        })
        .where(eq(schema.surveySessions.id, input.sessionId));

      // Update user totals
      await db
        .update(schema.users)
        .set({
          totalHoursWorked: sql`CAST(total_hours_worked + ${activeHours.toFixed(2)} AS DECIMAL(10,2))`,
          totalEarnings: sql`CAST(total_earnings + ${earnings} AS DECIMAL(10,2))`,
        })
        .where(eq(schema.users.id, userId));

      return { success: true };
    }),

  heartbeat: authedQuery
    .input(
      z.object({
        sessionId: z.number(),
        isActive: z.boolean(), // is user active or idle
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Check system status
      const settings = await db.select().from(schema.systemSettings).limit(1);
      if (settings.length === 0 || settings[0].systemStatus === "OFF") {
        // System is OFF - stop the session immediately
        const session = await db
          .select()
          .from(schema.surveySessions)
          .where(eq(schema.surveySessions.id, input.sessionId))
          .limit(1);

        if (session.length > 0 && session[0].status === "active") {
          await db
            .update(schema.surveySessions)
            .set({
              endTime: new Date(),
              status: "stopped_by_admin",
            })
            .where(eq(schema.surveySessions.id, input.sessionId));
        }

        return {
          success: false,
          systemStatus: "OFF",
          message: "System has been turned OFF by admin",
        };
      }

      const session = await db
        .select()
        .from(schema.surveySessions)
        .where(eq(schema.surveySessions.id, input.sessionId))
        .limit(1);

      if (session.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Session not found" });
      }

      const s = session[0];
      if (s.status !== "active") {
        return {
          success: false,
          systemStatus: settings[0].systemStatus,
          sessionStatus: s.status,
        };
      }

      return {
        success: true,
        systemStatus: settings[0].systemStatus,
        sessionStatus: s.status,
      };
    }),

  // Log activity (mouse, keyboard, etc.)
  logActivity: authedQuery
    .input(
      z.object({
        sessionId: z.number(),
        activityType: z.enum(["mouse", "keyboard", "click", "blur", "focus", "heartbeat"]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();

      await db.insert(schema.activityLogs).values({
        userId: ctx.user.id,
        sessionId: input.sessionId,
        activityType: input.activityType,
        timestamp: new Date(),
      });

      return { success: true };
    }),

  // Get user's active session
  getActive: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const sessions = await db
      .select()
      .from(schema.surveySessions)
      .where(
        and(
          eq(schema.surveySessions.userId, ctx.user.id),
          eq(schema.surveySessions.status, "active")
        )
      )
      .limit(1);

    return sessions.at(0) ?? null;
  }),

  // Get user's session history
  getHistory: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const sessions = await db
      .select()
      .from(schema.surveySessions)
      .where(eq(schema.surveySessions.userId, ctx.user.id))
      .orderBy(schema.surveySessions.createdAt);

    return sessions;
  }),

  // Get all sessions (admin)
  getAll: adminQuery.query(async () => {
    const db = getDb();
    const sessions = await db
      .select({
        session: schema.surveySessions,
        userName: schema.users.name,
        userEmail: schema.users.email,
        surveyTitle: schema.surveys.title,
      })
      .from(schema.surveySessions)
      .leftJoin(schema.users, eq(schema.surveySessions.userId, schema.users.id))
      .leftJoin(schema.surveys, eq(schema.surveySessions.surveyId, schema.surveys.id))
      .orderBy(schema.surveySessions.createdAt);

    return sessions;
  }),

  // Approve session hours (admin)
  approve: adminQuery
    .input(
      z.object({
        sessionId: z.number(),
        approvedHours: z.number().min(0),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const session = await db
        .select()
        .from(schema.surveySessions)
        .where(eq(schema.surveySessions.id, input.sessionId))
        .limit(1);

      if (session.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Session not found" });
      }

      const s = session[0];
      const settings = await db.select().from(schema.systemSettings).limit(1);
      const hourlyRate = settings.length > 0 ? Number(settings[0].hourlyRate) : 5;
      const earnings = (input.approvedHours * hourlyRate).toFixed(2);

      await db
        .update(schema.surveySessions)
        .set({
          approvedHours: input.approvedHours.toFixed(2),
          earnings,
          status: "approved",
        })
        .where(eq(schema.surveySessions.id, input.sessionId));

      // Update user totals
      await db
        .update(schema.users)
        .set({
          totalHoursWorked: sql`CAST(total_hours_worked + ${input.approvedHours.toFixed(2)} AS DECIMAL(10,2))`,
          totalEarnings: sql`CAST(total_earnings + ${earnings} AS DECIMAL(10,2))`,
        })
        .where(eq(schema.users.id, s.userId));

      return { success: true };
    }),

  // Reject session (admin)
  reject: adminQuery
    .input(z.object({ sessionId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      await db
        .update(schema.surveySessions)
        .set({ status: "rejected", approvedHours: "0.00", earnings: "0.00" })
        .where(eq(schema.surveySessions.id, input.sessionId));

      return { success: true };
    }),

  // Get today's work summary for user
  getTodaySummary: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const sessions = await db
      .select()
      .from(schema.surveySessions)
      .where(
        and(
          eq(schema.surveySessions.userId, ctx.user.id),
          gte(schema.surveySessions.startTime, today)
        )
      );

    const totalSeconds = sessions.reduce((sum, s) => {
      return sum + (Number(s.activeTime) || 0);
    }, 0);

    const approvedSeconds = sessions
      .filter((s) => s.status === "approved")
      .reduce((sum, s) => sum + Number(s.activeTime || 0), 0);

    const totalHours = totalSeconds / 3600;
    const approvedHours = approvedSeconds / 3600;

    return {
      totalSeconds,
      totalHours: totalHours.toFixed(2),
      approvedHours: approvedHours.toFixed(2),
      sessionCount: sessions.length,
    };
  }),
});
