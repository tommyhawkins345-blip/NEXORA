import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { Paths } from "@contracts/constants";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

// Auto-seed function
async function seedDatabase() {
  try {
    const db = getDb();

    // Check if system settings exist
    const existing = await db.select().from(schema.systemSettings).limit(1);

    if (existing.length === 0) {
      await db.insert(schema.systemSettings).values({
        systemStatus: "ON",
        hourlyRate: "5.00",
        payoutThreshold: "25.00",
        idleTimeoutSeconds: 300,
        maxDailyHours: "8.00",
      });
      console.log("[seed] System settings created");
    }

    // Check if admin exists
    const adminEmail = "admin@nexora.com";
    const adminExists = await db
      .select()
      .from(schema.users)
      .where(eq(schema.users.email, adminEmail))
      .limit(1);

    if (adminExists.length === 0) {
      const hashedPassword = await bcrypt.hash("admin123", 10);
      await db.insert(schema.users).values({
        name: "Admin",
        email: adminEmail,
        password: hashedPassword,
        isVerified: true,
        role: "admin",
        isBanned: false,
        totalHoursWorked: "0.00",
        totalEarnings: "0.00",
      });
      console.log("[seed] Admin user created (admin@nexora.com / admin123)");
    }

    // Create sample surveys if none exist
    const surveysExist = await db.select().from(schema.surveys).limit(1);
    if (surveysExist.length === 0) {
      await db.insert(schema.surveys).values([
        {
          title: "Market Research Survey",
          description: "Help us understand consumer behavior and preferences in the current market.",
          isActive: true,
        },
        {
          title: "Product Feedback Survey",
          description: "Share your thoughts on our latest product features and improvements.",
          isActive: true,
        },
        {
          title: "User Experience Survey",
          description: "Evaluate the usability and accessibility of our platform.",
          isActive: true,
        },
      ]);
      console.log("[seed] Sample surveys created");
    }
  } catch (err) {
    console.error("[seed] Error:", err);
  }
}

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.get(Paths.oauthCallback, createOAuthCallbackHandler());
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  seedDatabase();
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
