import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";
import { eq, sql } from "drizzle-orm";

export const adminRouter = createRouter({
  // Get all users
  getUsers: adminQuery.query(async () => {
    const db = getDb();
    const allUsers = await db
      .select({
        id: schema.users.id,
        name: schema.users.name,
        email: schema.users.email,
        role: schema.users.role,
        isVerified: schema.users.isVerified,
        isBanned: schema.users.isBanned,
        totalHoursWorked: schema.users.totalHoursWorked,
        totalEarnings: schema.users.totalEarnings,
        createdAt: schema.users.createdAt,
      })
      .from(schema.users)
      .orderBy(schema.users.createdAt);

    return allUsers;
  }),

  // Ban/unban user
  toggleBan: adminQuery
    .input(z.object({ userId: z.number(), isBanned: z.boolean() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(schema.users)
        .set({ isBanned: input.isBanned })
        .where(eq(schema.users.id, input.userId));
      return { success: true };
    }),

  // Get active sessions with user info
  getActiveSessions: adminQuery.query(async () => {
    const db = getDb();
    const sessions = await db
      .select({
        session: schema.surveySessions,
        userName: schema.users.name,
        userEmail: schema.users.email,
        surveyTitle: schema.surveys.title,
      })
      .from(schema.surveySessions)
      .leftJoin(schema.users, eq(schema.surveySessions.userId, schema.users.id))
      .leftJoin(schema.surveys, eq(schema.surveySessions.surveyId, schema.surveys.id))
      .where(eq(schema.surveySessions.status, "active"));

    return sessions;
  }),

  // Get system settings
  getSettings: adminQuery.query(async () => {
    const db = getDb();
    const settings = await db.select().from(schema.systemSettings).limit(1);
    return settings.at(0) ?? null;
  }),

  // Update system settings
  updateSettings: adminQuery
    .input(
      z.object({
        hourlyRate: z.number().min(0).optional(),
        payoutThreshold: z.number().min(0).optional(),
        idleTimeoutSeconds: z.number().min(10).optional(),
        maxDailyHours: z.number().min(0).max(24).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const settings = await db.select().from(schema.systemSettings).limit(1);

      const updateData: Partial<schema.InsertSystemSetting> = {};
      if (input.hourlyRate !== undefined) updateData.hourlyRate = input.hourlyRate.toFixed(2);
      if (input.payoutThreshold !== undefined)
        updateData.payoutThreshold = input.payoutThreshold.toFixed(2);
      if (input.idleTimeoutSeconds !== undefined)
        updateData.idleTimeoutSeconds = input.idleTimeoutSeconds;
      if (input.maxDailyHours !== undefined)
        updateData.maxDailyHours = input.maxDailyHours.toFixed(2);

      if (settings.length === 0) {
        await db.insert(schema.systemSettings).values({
          systemStatus: "ON",
          ...updateData,
        });
      } else {
        await db
          .update(schema.systemSettings)
          .set(updateData)
          .where(eq(schema.systemSettings.id, settings[0].id));
      }

      return { success: true };
    }),

  // Toggle system ON/OFF (CRITICAL)
  toggleSystem: adminQuery
    .input(z.object({ status: z.enum(["ON", "OFF"]) }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const settings = await db.select().from(schema.systemSettings).limit(1);

      if (settings.length === 0) {
        await db.insert(schema.systemSettings).values({
          systemStatus: input.status,
          hourlyRate: "5.00",
          payoutThreshold: "25.00",
          idleTimeoutSeconds: 300,
          maxDailyHours: "8.00",
        });
      } else {
        await db
          .update(schema.systemSettings)
          .set({ systemStatus: input.status })
          .where(eq(schema.systemSettings.id, settings[0].id));
      }

      // If turning OFF, stop all active sessions
      if (input.status === "OFF") {
        const activeSessions = await db
          .select()
          .from(schema.surveySessions)
          .where(eq(schema.surveySessions.status, "active"));

        for (const session of activeSessions) {
          await db
            .update(schema.surveySessions)
            .set({
              endTime: new Date(),
              status: "stopped_by_admin",
            })
            .where(eq(schema.surveySessions.id, session.id));
        }
      }

      return { success: true, status: input.status, stoppedSessions: input.status === "OFF" };
    }),

  // Get dashboard stats
  getStats: adminQuery.query(async () => {
    const db = getDb();

    const totalUsers = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(schema.users);

    const activeUsers = await db
      .select({ count: sql<number>`COUNT(DISTINCT user_id)` })
      .from(schema.surveySessions)
      .where(eq(schema.surveySessions.status, "active"));

    const totalSessions = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(schema.surveySessions);

    const pendingSessions = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(schema.surveySessions)
      .where(eq(schema.surveySessions.status, "submitted"));

    const totalPayouts = await db
      .select({
        amount: sql<string>`COALESCE(SUM(amount), 0)`,
      })
      .from(schema.payouts)
      .where(eq(schema.payouts.status, "paid"));

    const pendingPayouts = await db
      .select({
        amount: sql<string>`COALESCE(SUM(amount), 0)`,
      })
      .from(schema.payouts)
      .where(eq(schema.payouts.status, "pending"));

    return {
      totalUsers: totalUsers[0]?.count ?? 0,
      activeUsers: activeUsers[0]?.count ?? 0,
      totalSessions: totalSessions[0]?.count ?? 0,
      pendingSessions: pendingSessions[0]?.count ?? 0,
      totalPayouts: totalPayouts[0]?.amount ?? "0.00",
      pendingPayouts: pendingPayouts[0]?.amount ?? "0.00",
    };
  }),

  // Get user details with sessions
  getUserDetails: adminQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();

      const user = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, input.userId))
        .limit(1);

      if (user.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
      }

      const sessions = await db
        .select()
        .from(schema.surveySessions)
        .where(eq(schema.surveySessions.userId, input.userId))
        .orderBy(schema.surveySessions.createdAt);

      const payouts = await db
        .select()
        .from(schema.payouts)
        .where(eq(schema.payouts.userId, input.userId))
        .orderBy(schema.payouts.requestedAt);

      return {
        user: user[0],
        sessions,
        payouts,
      };
    }),
});
