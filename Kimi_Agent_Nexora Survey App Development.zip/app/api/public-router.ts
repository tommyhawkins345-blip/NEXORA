import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";

export const publicRouter = createRouter({
  systemStatus: publicQuery.query(async () => {
    const db = getDb();
    const settings = await db.select().from(schema.systemSettings).limit(1);
    return {
      status: settings.length > 0 ? settings[0].systemStatus : "OFF",
      hourlyRate: settings.length > 0 ? settings[0].hourlyRate : "5.00",
      payoutThreshold: settings.length > 0 ? settings[0].payoutThreshold : "25.00",
      idleTimeoutSeconds: settings.length > 0 ? settings[0].idleTimeoutSeconds : 300,
      maxDailyHours: settings.length > 0 ? settings[0].maxDailyHours : "8.00",
    };
  }),
});
