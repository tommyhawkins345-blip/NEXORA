import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  decimal,
  int,
  boolean,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).unique(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  password: varchar("password", { length: 255 }),
  avatar: text("avatar"),
  isVerified: boolean("is_verified").default(false).notNull(),
  verificationToken: varchar("verification_token", { length: 255 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  isBanned: boolean("is_banned").default(false).notNull(),
  totalHoursWorked: decimal("total_hours_worked", { precision: 10, scale: 2 }).default("0.00").notNull(),
  totalEarnings: decimal("total_earnings", { precision: 10, scale: 2 }).default("0.00").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("last_sign_in_at").defaultNow().notNull(),
});

export const surveys = mysqlTable("surveys", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const surveySessions = mysqlTable("survey_sessions", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  surveyId: bigint("survey_id", { mode: "number", unsigned: true }).notNull(),
  startTime: timestamp("start_time").defaultNow().notNull(),
  endTime: timestamp("end_time"),
  duration: int("duration").default(0),
  activeTime: int("active_time").default(0),
  approvedHours: decimal("approved_hours", { precision: 10, scale: 2 }).default("0.00"),
  earnings: decimal("earnings", { precision: 10, scale: 2 }).default("0.00"),
  status: mysqlEnum("status", [
    "active",
    "submitted",
    "stopped_by_admin",
    "pending",
    "approved",
    "rejected",
  ]).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const activityLogs = mysqlTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull(),
  activityType: varchar("activity_type", { length: 50 }).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const payouts = mysqlTable("payouts", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "paid", "rejected"])
    .default("pending")
    .notNull(),
  requestedAt: timestamp("requested_at").defaultNow().notNull(),
  processedAt: timestamp("processed_at"),
});

export const systemSettings = mysqlTable("system_settings", {
  id: serial("id").primaryKey(),
  systemStatus: mysqlEnum("system_status", ["ON", "OFF"]).default("OFF").notNull(),
  hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }).default("5.00").notNull(),
  payoutThreshold: decimal("payout_threshold", { precision: 10, scale: 2 }).default("25.00").notNull(),
  idleTimeoutSeconds: int("idle_timeout_seconds").default(300).notNull(),
  maxDailyHours: decimal("max_daily_hours", { precision: 10, scale: 2 }).default("8.00").notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Survey = typeof surveys.$inferSelect;
export type InsertSurvey = typeof surveys.$inferInsert;
export type SurveySession = typeof surveySessions.$inferSelect;
export type InsertSurveySession = typeof surveySessions.$inferInsert;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = typeof activityLogs.$inferInsert;
export type Payout = typeof payouts.$inferSelect;
export type InsertPayout = typeof payouts.$inferInsert;
export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = typeof systemSettings.$inferInsert;
