import { relations } from "drizzle-orm";
import { users, surveys, surveySessions, activityLogs, payouts } from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  sessions: many(surveySessions),
  payouts: many(payouts),
  activityLogs: many(activityLogs),
}));

export const surveysRelations = relations(surveys, ({ many }) => ({
  sessions: many(surveySessions),
}));

export const surveySessionsRelations = relations(surveySessions, ({ one, many }) => ({
  user: one(users, {
    fields: [surveySessions.userId],
    references: [users.id],
  }),
  survey: one(surveys, {
    fields: [surveySessions.surveyId],
    references: [surveys.id],
  }),
  activityLogs: many(activityLogs),
}));

export const activityLogsRelations = relations(activityLogs, ({ one }) => ({
  user: one(users, {
    fields: [activityLogs.userId],
    references: [users.id],
  }),
  session: one(surveySessions, {
    fields: [activityLogs.sessionId],
    references: [surveySessions.id],
  }),
}));

export const payoutsRelations = relations(payouts, ({ one }) => ({
  user: one(users, {
    fields: [payouts.userId],
    references: [users.id],
  }),
}));
