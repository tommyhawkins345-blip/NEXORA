import { getDb } from "../api/queries/connection";
import * as schema from "./schema";
import { eq } from "drizzle-orm";

async function seed() {
  const db = getDb();

  // Check if system settings exist
  const existing = await db.select().from(schema.systemSettings).limit(1);

  if (existing.length === 0) {
    await db.insert(schema.systemSettings).values({
      systemStatus: "ON",
      hourlyRate: "5.00",
      payoutThreshold: "25.00",
      idleTimeoutSeconds: 300,
      maxDailyHours: "8.00",
    });
    console.log("System settings seeded");
  }

  // Check if admin exists
  const adminEmail = "admin@nexora.com";
  const adminExists = await db
    .select()
    .from(schema.users)
    .where(eq(schema.users.email, adminEmail))
    .limit(1);

  if (adminExists.length === 0) {
    // Create admin with password 'admin123' (hashed with bcrypt)
    // bcrypt hash of 'admin123' with 10 rounds
    const bcrypt = require("bcryptjs");
    const hashedPassword = await bcrypt.hash("admin123", 10);

    await db.insert(schema.users).values({
      name: "Admin",
      email: adminEmail,
      password: hashedPassword,
      isVerified: true,
      role: "admin",
      isBanned: false,
      totalHoursWorked: "0.00",
      totalEarnings: "0.00",
    });
    console.log("Admin user seeded (admin@nexora.com / admin123)");
  }

  // Create some sample surveys
  const surveysExist = await db.select().from(schema.surveys).limit(1);
  if (surveysExist.length === 0) {
    await db.insert(schema.surveys).values([
      {
        title: "Market Research Survey",
        description: "Help us understand consumer behavior and preferences in the current market.",
        isActive: true,
      },
      {
        title: "Product Feedback Survey",
        description: "Share your thoughts on our latest product features and improvements.",
        isActive: true,
      },
      {
        title: "User Experience Survey",
        description: "Evaluate the usability and accessibility of our platform.",
        isActive: true,
      },
    ]);
    console.log("Sample surveys seeded");
  }

  console.log("Seed complete");
}

seed().catch(console.error);
