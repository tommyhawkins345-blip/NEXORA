export const LOGIN_PATH = "/login";
export const SIGNUP_PATH = "/signup";
export const VERIFY_PATH = "/verify";
export const DASHBOARD_PATH = "/dashboard";
export const ADMIN_PATH = "/admin";
export const SURVEY_PATH = "/survey";
