import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router";
import { Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center px-4">
      <Card className="w-full max-w-md">
        <CardContent className="pt-6 text-center">
          <h1 className="text-6xl font-bold text-[#007BFF] mb-4">404</h1>
          <p className="text-xl text-gray-700 mb-2">Page Not Found</p>
          <p className="text-gray-600 mb-6">
            The page you are looking for does not exist.
          </p>
          <Link to="/">
            <Button className="bg-[#007BFF] hover:bg-blue-700">
              <Home className="w-4 h-4 mr-2" />
              Go Home
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
