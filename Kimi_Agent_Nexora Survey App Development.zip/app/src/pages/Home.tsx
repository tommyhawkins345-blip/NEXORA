import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, DollarSign, Shield, BarChart3 } from "lucide-react";
import { Link } from "react-router";
import { useAuth } from "@/hooks/useAuth";

export default function Home() {
  const { isAuthenticated, isAdmin } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Navbar */}
      <nav className="bg-white border-b border-blue-100 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#007BFF] rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">N</span>
          </div>
          <span className="text-xl font-bold text-[#007BFF]">Nexora</span>
        </div>
        <div className="flex items-center gap-4">
          {isAuthenticated ? (
            <>
              <Link to="/dashboard">
                <Button variant="outline">Dashboard</Button>
              </Link>
              {isAdmin && (
                <Link to="/admin">
                  <Button variant="outline" className="border-[#FFD700] text-[#FFD700]">Admin</Button>
                </Link>
              )}
            </>
          ) : (
            <>
              <Link to="/login">
                <Button variant="outline">Login</Button>
              </Link>
              <Link to="/signup">
                <Button className="bg-[#007BFF] hover:bg-blue-700">Sign Up</Button>
              </Link>
            </>
          )}
        </div>
      </nav>

      {/* Hero */}
      <div className="max-w-6xl mx-auto px-6 py-16">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Earn Money by Completing{" "}
            <span className="text-[#007BFF]">Surveys</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Nexora is a survey-based earning platform where you get paid for your time.
            No points, no gimmicks — just real money for real work.
          </p>
          {!isAuthenticated && (
            <Link to="/signup">
              <Button size="lg" className="bg-[#007BFF] hover:bg-blue-700 text-lg px-8">
                Get Started
              </Button>
            </Link>
          )}
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="border-blue-100">
            <CardHeader>
              <Clock className="w-10 h-10 text-[#007BFF] mb-2" />
              <CardTitle className="text-lg">Time-Based Pay</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Get paid $5 per hour for every minute you work. No hidden fees.</p>
            </CardContent>
          </Card>
          <Card className="border-blue-100">
            <CardHeader>
              <DollarSign className="w-10 h-10 text-[#FFD700] mb-2" />
              <CardTitle className="text-lg">Real Earnings</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Withdraw your earnings once you hit the minimum threshold.</p>
            </CardContent>
          </Card>
          <Card className="border-blue-100">
            <CardHeader>
              <Shield className="w-10 h-10 text-[#007BFF] mb-2" />
              <CardTitle className="text-lg">Anti-Cheat System</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Advanced activity detection ensures fair pay for fair work.</p>
            </CardContent>
          </Card>
          <Card className="border-blue-100">
            <CardHeader>
              <BarChart3 className="w-10 h-10 text-[#FFD700] mb-2" />
              <CardTitle className="text-lg">Live Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Track your hours, earnings, and progress in real-time.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
