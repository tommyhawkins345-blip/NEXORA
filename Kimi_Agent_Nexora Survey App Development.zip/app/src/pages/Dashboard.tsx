import { useEffect, useState, useCallback } from "react";
import { useNavigate, Link } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import {
  Clock,
  DollarSign,
  Play,
  History,
  Power,
  LogOut,
  Activity,
  AlertCircle,
} from "lucide-react";

export default function Dashboard() {
  const navigate = useNavigate();
  const { user, isLoading, isAuthenticated, logout, isAdmin } = useAuth({
    redirectOnUnauthenticated: true,
  });

  const [currentTime, setCurrentTime] = useState(new Date());

  // Fetch data
  const { data: systemStatus } = trpc.public.systemStatus.useQuery(undefined, {
    refetchInterval: 5000,
  });
  const { data: surveys } = trpc.survey.list.useQuery();
  const { data: activeSession } = trpc.session.getActive.useQuery(undefined, {
    refetchInterval: 5000,
  });
  const { data: todaySummary } = trpc.session.getTodaySummary.useQuery(undefined, {
    refetchInterval: 10000,
  });
  const { data: sessionHistory } = trpc.session.getHistory.useQuery();
  const { data: myPayouts } = trpc.payout.getMine.useQuery();
  const { data: settings } = trpc.public.systemStatus.useQuery();

  const requestPayout = trpc.payout.request.useMutation({
    onSuccess: () => {
      toast.success("Payout requested successfully!");
      utils.payout.getMine.invalidate();
      utils.customAuth.me.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const utils = trpc.useUtils();

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleStartSurvey = (surveyId: number) => {
    if (systemStatus?.status === "OFF") {
      toast.error("System is currently OFF. Please try again later.");
      return;
    }
    navigate(`/survey/${surveyId}`);
  };

  const handleRequestPayout = useCallback(() => {
    if (!user?.totalEarnings) return;
    const earnings = Number(user.totalEarnings);
    const threshold = Number(settings?.payoutThreshold || 25);
    if (earnings < threshold) {
      toast.error(`Minimum payout threshold is $${threshold}`);
      return;
    }
    requestPayout.mutate({ amount: earnings });
  }, [user, settings, requestPayout]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#007BFF]"></div>
      </div>
    );
  }

  if (!isAuthenticated) return null;

  const maxDailyHours = 8;
  const todayHours = Number(todaySummary?.totalHours || 0);
  const dailyProgress = Math.min((todayHours / maxDailyHours) * 100, 100);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Navbar */}
      <nav className="bg-white border-b border-blue-100 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#007BFF] rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">N</span>
          </div>
          <span className="text-xl font-bold text-[#007BFF]">Nexora</span>
        </div>
        <div className="flex items-center gap-4">
          {/* System Status Indicator */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gray-100">
            <Power className={`w-4 h-4 ${systemStatus?.status === "ON" ? "text-green-500" : "text-red-500"}`} />
            <span className={`text-sm font-medium ${systemStatus?.status === "ON" ? "text-green-600" : "text-red-600"}`}>
              System {systemStatus?.status || "OFF"}
            </span>
          </div>
          {isAdmin && (
            <Link to="/admin">
              <Button variant="outline" size="sm" className="border-[#FFD700] text-[#FFD700]">
                Admin Panel
              </Button>
            </Link>
          )}
          <Button variant="ghost" size="sm" onClick={logout}>
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Welcome */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome, {user?.name}!
          </h1>
          <p className="text-gray-600">
            {currentTime.toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Today&apos;s Hours</p>
                  <p className="text-2xl font-bold text-[#007BFF]">
                    {todaySummary?.totalHours || "0.00"}h
                  </p>
                </div>
                <Clock className="w-8 h-8 text-blue-300" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Earnings</p>
                  <p className="text-2xl font-bold text-[#FFD700]">
                    ${Number(user?.totalEarnings || 0).toFixed(2)}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-yellow-300" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Sessions Today</p>
                  <p className="text-2xl font-bold text-[#007BFF]">
                    {todaySummary?.sessionCount || 0}
                  </p>
                </div>
                <Activity className="w-8 h-8 text-blue-300" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Payouts</p>
                  <p className="text-2xl font-bold text-orange-500">
                    {myPayouts?.filter((p) => p.status === "pending").length || 0}
                  </p>
                </div>
                <AlertCircle className="w-8 h-8 text-orange-300" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Daily Progress */}
        <Card className="mb-8 border-blue-100">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#007BFF]" />
              Daily Progress (Max 8 Hours)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">{todayHours.toFixed(2)}h worked</span>
              <span className="text-sm text-gray-600">{maxDailyHours}h max</span>
            </div>
            <Progress value={dailyProgress} className="h-3" />
            <p className="text-sm text-gray-500 mt-2">
              {(maxDailyHours - todayHours).toFixed(2)} hours remaining today
            </p>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Available Surveys */}
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Play className="w-5 h-5 text-[#007BFF]" />
              Available Surveys
            </h2>
            {systemStatus?.status === "OFF" ? (
              <Card className="border-red-200 bg-red-50">
                <CardContent className="pt-6 text-center">
                  <Power className="w-10 h-10 text-red-500 mx-auto mb-3" />
                  <p className="text-red-600 font-medium">System is currently OFF</p>
                  <p className="text-red-500 text-sm mt-1">
                    Surveys are unavailable. Please check back later.
                  </p>
                </CardContent>
              </Card>
            ) : activeSession ? (
              <Card className="border-yellow-200 bg-yellow-50">
                <CardContent className="pt-6 text-center">
                  <Clock className="w-10 h-10 text-[#FFD700] mx-auto mb-3" />
                  <p className="text-yellow-700 font-medium">You have an active session</p>
                  <p className="text-yellow-600 text-sm mt-1">
                    Survey #{activeSession.surveyId} - started{" "}
                    {new Date(activeSession.startTime).toLocaleTimeString()}
                  </p>
                  <Link to={`/survey/${activeSession.surveyId}`}>
                    <Button className="mt-4 bg-[#FFD700] hover:bg-yellow-500 text-black">
                      Continue Working
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {surveys?.map((survey) => (
                  <Card key={survey.id} className="border-blue-100 hover:border-[#007BFF] transition-colors">
                    <CardContent className="p-4 flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-gray-900">{survey.title}</h3>
                        <p className="text-sm text-gray-600 line-clamp-1">{survey.description}</p>
                      </div>
                      <Button
                        size="sm"
                        className="bg-[#007BFF] hover:bg-blue-700"
                        onClick={() => handleStartSurvey(survey.id)}
                      >
                        <Play className="w-4 h-4 mr-1" />
                        Start
                      </Button>
                    </CardContent>
                  </Card>
                ))}
                {(!surveys || surveys.length === 0) && (
                  <p className="text-gray-500 text-center py-8">No surveys available</p>
                )}
              </div>
            )}
          </div>

          {/* Session History */}
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <History className="w-5 h-5 text-[#007BFF]" />
              Session History
            </h2>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {sessionHistory?.map((session) => (
                <Card key={session.id} className="border-blue-100">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">Survey #{session.surveyId}</span>
                      <Badge
                        variant={
                          session.status === "approved"
                            ? "default"
                            : session.status === "rejected"
                            ? "destructive"
                            : session.status === "active"
                            ? "secondary"
                            : "outline"
                        }
                      >
                        {session.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>
                        Duration: {Math.floor((session.duration || 0) / 60)}m {(session.duration || 0) % 60}s
                      </p>
                      <p>Active Time: {Math.floor((session.activeTime || 0) / 60)}m</p>
                      {session.approvedHours && Number(session.approvedHours) > 0 && (
                        <p className="text-[#007BFF] font-medium">
                          Approved: {Number(session.approvedHours).toFixed(2)}h | ${Number(session.earnings || 0).toFixed(2)}
                        </p>
                      )}
                      <p className="text-xs text-gray-400">
                        {new Date(session.startTime).toLocaleDateString()}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {(!sessionHistory || sessionHistory.length === 0) && (
                <p className="text-gray-500 text-center py-8">No sessions yet</p>
              )}
            </div>
          </div>
        </div>

        {/* Payout Section */}
        <Card className="mt-8 border-[#FFD700]">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-[#FFD700]" />
              Payouts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-gray-600">Available Earnings</p>
                <p className="text-2xl font-bold text-[#FFD700]">
                  ${Number(user?.totalEarnings || 0).toFixed(2)}
                </p>
              </div>
              <Button
                className="bg-[#FFD700] hover:bg-yellow-500 text-black"
                onClick={handleRequestPayout}
                disabled={requestPayout.isPending}
              >
                {requestPayout.isPending ? "Processing..." : "Request Payout"}
              </Button>
            </div>
            <p className="text-sm text-gray-500">
              Minimum payout: ${Number(settings?.payoutThreshold || 25).toFixed(2)}
            </p>

            {myPayouts && myPayouts.length > 0 && (
              <div className="mt-4 space-y-2">
                <h4 className="font-medium text-sm">Payout History</h4>
                {myPayouts.map((payout) => (
                  <div
                    key={payout.id}
                    className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-md"
                  >
                    <span className="text-sm">${Number(payout.amount).toFixed(2)}</span>
                    <Badge
                      variant={
                        payout.status === "paid"
                          ? "default"
                          : payout.status === "approved"
                          ? "secondary"
                          : payout.status === "pending"
                          ? "outline"
                          : "destructive"
                      }
                    >
                      {payout.status}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
