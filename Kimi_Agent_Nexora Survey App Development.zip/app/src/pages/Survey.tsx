import { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { Clock, Pause, Play, Square, AlertTriangle, Eye, EyeOff } from "lucide-react";

export default function Survey() {
  const { surveyId } = useParams<{ surveyId: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth({ redirectOnUnauthenticated: true });

  const [elapsedTime, setElapsedTime] = useState(0); // seconds
  const [activeTime, setActiveTime] = useState(0); // seconds (excluding idle)
  const [isIdle, setIsIdle] = useState(false);
  const [idleTime, setIdleTime] = useState(0);
  const [isTabVisible, setIsTabVisible] = useState(true);
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [systemOff, setSystemOff] = useState(false);

  const idleTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const heartbeatIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timerIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastActivityRef = useRef(Date.now());
  const sessionStartRef = useRef<Date | null>(null);

  const surveyIdNum = Number(surveyId);

  // Queries
  const { data: survey } = trpc.survey.getById.useQuery({ id: surveyIdNum }, {
    enabled: !!surveyIdNum,
  });
  const { data: systemStatus } = trpc.public.systemStatus.useQuery(undefined, {
    refetchInterval: 5000,
  });

  // Mutations
  const startSession = trpc.session.start.useMutation({
    onSuccess: (data) => {
      setSessionId(data.sessionId);
      sessionStartRef.current = new Date(data.startTime);
      toast.success("Session started!");
    },
    onError: (err) => {
      toast.error(err.message);
      navigate("/dashboard");
    },
  });

  const stopSession = trpc.session.stop.useMutation({
    onSuccess: () => {
      toast.success("Session submitted successfully!");
      navigate("/dashboard");
    },
    onError: (err) => toast.error(err.message),
  });

  const heartbeat = trpc.session.heartbeat.useMutation({
    onSuccess: (data) => {
      if (data.systemStatus === "OFF") {
        setSystemOff(true);
        handleStop("System turned OFF by admin");
      }
      if (!data.success && data.sessionStatus !== "active") {
        toast.error("Session ended remotely");
        navigate("/dashboard");
      }
    },
    onError: () => {
      // Silently handle heartbeat errors
    },
  });

  const logActivity = trpc.session.logActivity.useMutation();

  // Start session on mount
  useEffect(() => {
    if (isAuthenticated && surveyIdNum && !sessionId) {
      startSession.mutate({ surveyId: surveyIdNum });
    }
  }, [isAuthenticated, surveyIdNum]);

  // Timer logic
  useEffect(() => {
    if (sessionId && !systemOff) {
      timerIntervalRef.current = setInterval(() => {
        setElapsedTime((prev) => prev + 1);
        if (!isIdle && isTabVisible) {
          setActiveTime((prev) => prev + 1);
        } else {
          setIdleTime((prev) => prev + 1);
        }
      }, 1000);
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [sessionId, isIdle, isTabVisible, systemOff]);

  // Heartbeat
  useEffect(() => {
    if (sessionId && !systemOff) {
      heartbeatIntervalRef.current = setInterval(() => {
        heartbeat.mutate({ sessionId, isActive: !isIdle && isTabVisible });
      }, 10000); // every 10 seconds
    }
    return () => {
      if (heartbeatIntervalRef.current) clearInterval(heartbeatIntervalRef.current);
    };
  }, [sessionId, isIdle, isTabVisible, systemOff]);

  // Activity tracking
  const resetIdle = useCallback(() => {
    lastActivityRef.current = Date.now();
    if (isIdle) {
      setIsIdle(false);
      toast.info("Timer resumed");
    }
    if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);
    idleTimeoutRef.current = setTimeout(() => {
      setIsIdle(true);
      toast.warning("Timer paused due to inactivity");
    }, (systemStatus?.idleTimeoutSeconds || 300) * 1000);
  }, [isIdle, systemStatus?.idleTimeoutSeconds]);

  useEffect(() => {
    const events = ["mousemove", "keydown", "click", "scroll", "touchstart"];
    const handleActivity = () => {
      if (sessionId && !systemOff) {
        resetIdle();
        // Log activity occasionally (throttle)
        if (Math.random() < 0.1) {
          logActivity.mutate({ sessionId, activityType: "mouse" });
        }
      }
    };

    events.forEach((event) => document.addEventListener(event, handleActivity));
    resetIdle();

    return () => {
      events.forEach((event) => document.removeEventListener(event, handleActivity));
      if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);
    };
  }, [sessionId, systemOff, resetIdle]);

  // Tab visibility tracking
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setIsTabVisible(false);
        setIsIdle(true);
        if (sessionId) {
          logActivity.mutate({ sessionId, activityType: "blur" });
        }
      } else {
        setIsTabVisible(true);
        setIsIdle(false);
        resetIdle();
        if (sessionId) {
          logActivity.mutate({ sessionId, activityType: "focus" });
        }
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, [sessionId, resetIdle]);

  // Prevent closing tab with active session
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (sessionId && !systemOff) {
        e.preventDefault();
        e.returnValue = "You have an active survey session. Are you sure you want to leave?";
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [sessionId, systemOff]);

  const handleStop = useCallback(
    (reason?: string) => {
      if (!sessionId) return;
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (heartbeatIntervalRef.current) clearInterval(heartbeatIntervalRef.current);
      if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);

      stopSession.mutate({
        sessionId,
        finalDuration: elapsedTime,
        finalActiveTime: activeTime,
      });

      if (reason) {
        toast.error(reason);
      }
    },
    [sessionId, elapsedTime, activeTime]
  );

  // Format time display
  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const hourlyRate = Number(systemStatus?.hourlyRate || 5);
  const currentEarnings = (activeTime / 3600) * hourlyRate;

  if (systemOff) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center px-4">
        <Card className="w-full max-w-md border-red-200">
          <CardContent className="pt-6 text-center">
            <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-red-600 mb-2">System Turned OFF</h2>
            <p className="text-gray-600 mb-4">
              The admin has turned the system OFF. Your session has been saved.
            </p>
            <Button onClick={() => navigate("/dashboard")} className="bg-[#007BFF] hover:bg-blue-700">
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-blue-100 px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-[#007BFF] rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">N</span>
            </div>
            <div>
              <h1 className="font-bold text-gray-900">{survey?.title || "Survey"}</h1>
              <p className="text-sm text-gray-600">{survey?.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant={isIdle ? "destructive" : "default"}>
              {isIdle ? (
                <><Pause className="w-3 h-3 mr-1" /> Idle</>
              ) : (
                <><Play className="w-3 h-3 mr-1" /> Active</>
              )}
            </Badge>
            {!isTabVisible && (
              <Badge variant="outline" className="text-orange-500">
                <EyeOff className="w-3 h-3 mr-1" /> Hidden
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Timer Display */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        <Card className="mb-6 border-[#007BFF]">
          <CardContent className="p-8">
            <div className="text-center">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Clock className={`w-8 h-8 ${isIdle ? "text-gray-400" : "text-[#007BFF]"}`} />
                <span className="text-sm text-gray-600 uppercase tracking-wide">Live Timer</span>
              </div>
              <div className={`text-6xl font-mono font-bold mb-2 ${isIdle ? "text-gray-400" : "text-[#007BFF]"}`}>
                {formatTime(elapsedTime)}
              </div>
              <div className="flex items-center justify-center gap-6 text-sm text-gray-600">
                <span>Active: {formatTime(activeTime)}</span>
                <span className="text-gray-300">|</span>
                <span className="text-orange-500">Idle: {formatTime(idleTime)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Earnings */}
        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <Card className="border-[#FFD700]">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-gray-600">Current Earnings</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-[#FFD700]">${currentEarnings.toFixed(2)}</p>
              <p className="text-sm text-gray-500">at ${hourlyRate}/hour</p>
            </CardContent>
          </Card>
          <Card className="border-blue-100">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-gray-600">Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  {isTabVisible ? (
                    <><Eye className="w-4 h-4 text-green-500" /> <span className="text-sm text-green-600">Tab visible</span></>
                  ) : (
                    <><EyeOff className="w-4 h-4 text-red-500" /> <span className="text-sm text-red-600">Tab hidden - timer paused</span></>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {isIdle ? (
                    <><Pause className="w-4 h-4 text-orange-500" /> <span className="text-sm text-orange-600">Idle - timer paused</span></>
                  ) : (
                    <><Play className="w-4 h-4 text-green-500" /> <span className="text-sm text-green-600">Active - timer running</span></>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Instructions */}
        <Card className="mb-6 border-blue-100">
          <CardHeader>
            <CardTitle className="text-lg">Survey Instructions</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-start gap-2">
                <span className="text-[#007BFF] font-bold">1.</span>
                Keep this tab active. Timer pauses if you switch tabs.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#007BFF] font-bold">2.</span>
                Stay active with mouse/keyboard. Timer pauses after {systemStatus?.idleTimeoutSeconds || 300}s of inactivity.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#007BFF] font-bold">3.</span>
                Only active time counts toward your earnings.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#007BFF] font-bold">4.</span>
                Click Submit when done. Admin will review and approve your hours.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#007BFF] font-bold">5.</span>
                Maximum {Number(systemStatus?.maxDailyHours || 8).toFixed(0)} hours per day.
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Submit Button */}
        <div className="flex justify-center">
          <Button
            size="lg"
            className="bg-red-500 hover:bg-red-600 text-white px-8"
            onClick={() => handleStop()}
            disabled={stopSession.isPending || !sessionId}
          >
            <Square className="w-5 h-5 mr-2" />
            {stopSession.isPending ? "Submitting..." : "Submit Survey & Stop Timer"}
          </Button>
        </div>
      </div>
    </div>
  );
}
