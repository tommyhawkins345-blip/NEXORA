import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/providers/trpc";
import { Link, useSearchParams, useNavigate } from "react-router";
import { toast } from "sonner";
import { Loader2, CheckCircle, Mail } from "lucide-react";

export default function Verify() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const email = searchParams.get("email") || "";
  const token = searchParams.get("token") || "";
  const [manualToken, setManualToken] = useState("");

  const verifyMutation = trpc.customAuth.verifyEmail.useMutation({
    onSuccess: () => {
      toast.success("Email verified! You can now login.");
      setTimeout(() => navigate("/login"), 1500);
    },
    onError: (err) => {
      toast.error(err.message);
    },
  });

  useEffect(() => {
    if (email && token) {
      verifyMutation.mutate({ email, token });
    }
  }, [email, token]);

  const handleManualVerify = () => {
    if (!email || !manualToken) {
      toast.error("Please enter email and token");
      return;
    }
    verifyMutation.mutate({ email, token: manualToken });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-8 h-8 bg-[#007BFF] rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">N</span>
            </div>
            <span className="text-xl font-bold text-[#007BFF]">Nexora</span>
          </div>
          <CardTitle>Verify Your Email</CardTitle>
        </CardHeader>
        <CardContent>
          {verifyMutation.isPending ? (
            <div className="text-center py-8">
              <Loader2 className="w-10 h-10 animate-spin mx-auto text-[#007BFF] mb-4" />
              <p className="text-gray-600">Verifying your email...</p>
            </div>
          ) : verifyMutation.isSuccess ? (
            <div className="text-center py-8">
              <CheckCircle className="w-16 h-16 mx-auto text-green-500 mb-4" />
              <p className="text-lg font-medium text-gray-900 mb-2">Email Verified!</p>
              <p className="text-gray-600 mb-4">Redirecting to login...</p>
              <Link to="/login">
                <Button className="bg-[#007BFF] hover:bg-blue-700">Go to Login</Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="text-center py-4">
                <Mail className="w-12 h-12 mx-auto text-[#007BFF] mb-3" />
                <p className="text-gray-600">
                  {email
                    ? `Verification email sent to ${email}`
                    : "Please enter your email and verification token"}
                </p>
              </div>

              {!email && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <input
                    type="email"
                    className="w-full px-3 py-2 border rounded-md"
                    placeholder="you@example.com"
                    value={email}
                    onChange={() => {}}
                  />
                </div>
              )}

              <div className="space-y-2">
                <label className="text-sm font-medium">Verification Token</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border rounded-md"
                  placeholder="Enter token from email"
                  value={token || manualToken}
                  onChange={(e) => setManualToken(e.target.value)}
                />
              </div>

              <Button
                className="w-full bg-[#007BFF] hover:bg-blue-700"
                onClick={handleManualVerify}
                disabled={verifyMutation.isPending}
              >
                {verifyMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  "Verify Email"
                )}
              </Button>

              <p className="text-center text-sm text-gray-600">
                Already verified?{" "}
                <Link to="/login" className="text-[#007BFF] hover:underline">
                  Login
                </Link>
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
