import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import {
  Users,
  Settings,
  Power,
  DollarSign,
  CheckCircle,
  XCircle,
  Activity,
  BarChart3,
  Ban,
  ArrowLeft,
  Loader2,
  Plus,
} from "lucide-react";

export default function Admin() {
  const { isLoading, isAuthenticated, isAdmin, logout } = useAuth({
    redirectOnUnauthenticated: true,
  });

  const [newSurveyTitle, setNewSurveyTitle] = useState("");
  const [newSurveyDesc, setNewSurveyDesc] = useState("");
  const [approveHours, setApproveHours] = useState<string>("");

  // Queries
  const { data: stats, refetch: refetchStats } = trpc.admin.getStats.useQuery();
  const { data: users, refetch: refetchUsers } = trpc.admin.getUsers.useQuery();
  const { data: activeSessions, refetch: refetchActive } = trpc.admin.getActiveSessions.useQuery(undefined, {
    refetchInterval: 5000,
  });
  const { data: allSessions, refetch: refetchSessions } = trpc.session.getAll.useQuery();
  const { data: allPayouts, refetch: refetchPayouts } = trpc.payout.getAll.useQuery();
  const { data: settings } = trpc.admin.getSettings.useQuery();
  const { data: surveys } = trpc.survey.list.useQuery();
  const { data: systemStatus } = trpc.public.systemStatus.useQuery(undefined, {
    refetchInterval: 3000,
  });

  const utils = trpc.useUtils();

  // Mutations
  const toggleSystem = trpc.admin.toggleSystem.useMutation({
    onSuccess: (data) => {
      toast.success(`System turned ${data.status}`);
      if (data.stoppedSessions) {
        toast.info("All active sessions have been stopped");
      }
      utils.public.systemStatus.invalidate();
      refetchActive();
      refetchStats();
    },
    onError: (err) => toast.error(err.message),
  });

  const toggleBan = trpc.admin.toggleBan.useMutation({
    onSuccess: () => {
      toast.success("User status updated");
      refetchUsers();
    },
    onError: (err) => toast.error(err.message),
  });

  const updateSettings = trpc.admin.updateSettings.useMutation({
    onSuccess: () => {
      toast.success("Settings updated");
      utils.admin.getSettings.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const createSurvey = trpc.survey.create.useMutation({
    onSuccess: () => {
      toast.success("Survey created");
      setNewSurveyTitle("");
      setNewSurveyDesc("");
      utils.survey.list.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const approveSession = trpc.session.approve.useMutation({
    onSuccess: () => {
      toast.success("Session approved");
      refetchSessions();
      refetchStats();
    },
    onError: (err) => toast.error(err.message),
  });

  const rejectSession = trpc.session.reject.useMutation({
    onSuccess: () => {
      toast.success("Session rejected");
      refetchSessions();
    },
    onError: (err) => toast.error(err.message),
  });

  const approvePayout = trpc.payout.approve.useMutation({
    onSuccess: () => {
      toast.success("Payout approved");
      refetchPayouts();
    },
    onError: (err) => toast.error(err.message),
  });

  const markPaid = trpc.payout.markPaid.useMutation({
    onSuccess: () => {
      toast.success("Payout marked as paid");
      refetchPayouts();
    },
    onError: (err) => toast.error(err.message),
  });

  const rejectPayout = trpc.payout.reject.useMutation({
    onSuccess: () => {
      toast.success("Payout rejected");
      refetchPayouts();
    },
    onError: (err) => toast.error(err.message),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-[#007BFF]" />
      </div>
    );
  }

  if (!isAuthenticated || !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-bold text-red-600 mb-2">Access Denied</h2>
            <p className="text-gray-600 mb-4">You need admin privileges to access this page.</p>
            <Link to="/dashboard">
              <Button className="bg-[#007BFF] hover:bg-blue-700">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Navbar */}
      <nav className="bg-white border-b border-blue-100 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#007BFF] rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">N</span>
          </div>
          <span className="text-xl font-bold text-[#007BFF]">Nexora Admin</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gray-100">
            <Power className={`w-4 h-4 ${systemStatus?.status === "ON" ? "text-green-500" : "text-red-500"}`} />
            <span className={`text-sm font-medium ${systemStatus?.status === "ON" ? "text-green-600" : "text-red-600"}`}>
              System {systemStatus?.status || "OFF"}
            </span>
          </div>
          <Link to="/dashboard">
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
          </Link>
          <Button variant="ghost" size="sm" onClick={logout}>
            Logout
          </Button>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold text-[#007BFF]">{stats?.totalUsers || 0}</p>
                </div>
                <Users className="w-8 h-8 text-blue-300" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Now</p>
                  <p className="text-2xl font-bold text-green-500">{stats?.activeUsers || 0}</p>
                </div>
                <Activity className="w-8 h-8 text-green-300" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-blue-100">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Review</p>
                  <p className="text-2xl font-bold text-orange-500">{stats?.pendingSessions || 0}</p>
                </div>
                <BarChart3 className="w-8 h-8 text-orange-300" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-[#FFD700]">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Paid</p>
                  <p className="text-2xl font-bold text-[#FFD700]">${Number(stats?.totalPayouts || 0).toFixed(2)}</p>
                </div>
                <DollarSign className="w-8 h-8 text-yellow-300" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* System Control */}
        <Card className="mb-8 border-[#007BFF]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Power className="w-5 h-5 text-[#007BFF]" />
              System Control
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-lg font-medium">
                  System is currently{" "}
                  <span className={systemStatus?.status === "ON" ? "text-green-600" : "text-red-600"}>
                    {systemStatus?.status || "OFF"}
                  </span>
                </p>
                <p className="text-sm text-gray-500">
                  {systemStatus?.status === "ON"
                    ? "Users can access and work on surveys"
                    : "All surveys are unavailable. Active sessions will be stopped."}
                </p>
              </div>
              <div className="flex items-center gap-4">
                <Switch
                  checked={systemStatus?.status === "ON"}
                  onCheckedChange={(checked) =>
                    toggleSystem.mutate({ status: checked ? "ON" : "OFF" })
                  }
                />
                <Button
                  variant={systemStatus?.status === "ON" ? "destructive" : "default"}
                  onClick={() =>
                    toggleSystem.mutate({ status: systemStatus?.status === "ON" ? "OFF" : "ON" })
                  }
                  disabled={toggleSystem.isPending}
                >
                  {toggleSystem.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : systemStatus?.status === "ON" ? (
                    "Turn OFF"
                  ) : (
                    "Turn ON"
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList className="bg-white border">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="sessions">Sessions</TabsTrigger>
            <TabsTrigger value="payouts">Payouts</TabsTrigger>
            <TabsTrigger value="surveys">Surveys</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>All Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-3">Name</th>
                        <th className="text-left py-2 px-3">Email</th>
                        <th className="text-left py-2 px-3">Role</th>
                        <th className="text-left py-2 px-3">Hours</th>
                        <th className="text-left py-2 px-3">Earnings</th>
                        <th className="text-left py-2 px-3">Status</th>
                        <th className="text-left py-2 px-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users?.map((u) => (
                        <tr key={u.id} className="border-b hover:bg-gray-50">
                          <td className="py-2 px-3">{u.name}</td>
                          <td className="py-2 px-3">{u.email}</td>
                          <td className="py-2 px-3">
                            <Badge variant={u.role === "admin" ? "default" : "outline"}>{u.role}</Badge>
                          </td>
                          <td className="py-2 px-3">{Number(u.totalHoursWorked).toFixed(2)}h</td>
                          <td className="py-2 px-3">${Number(u.totalEarnings).toFixed(2)}</td>
                          <td className="py-2 px-3">
                            {u.isBanned ? (
                              <Badge variant="destructive">Banned</Badge>
                            ) : (
                              <Badge variant="default">Active</Badge>
                            )}
                          </td>
                          <td className="py-2 px-3">
                            <Button
                              size="sm"
                              variant={u.isBanned ? "outline" : "destructive"}
                              onClick={() => toggleBan.mutate({ userId: u.id, isBanned: !u.isBanned })}
                            >
                              {u.isBanned ? "Unban" : <><Ban className="w-3 h-3 mr-1" /> Ban</>}
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sessions Tab */}
          <TabsContent value="sessions">
            <div className="grid lg:grid-cols-2 gap-4">
              {/* Active Sessions */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-green-500" />
                    Active Sessions (Live)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {activeSessions?.map(({ session, userName, surveyTitle }) => (
                      <div key={session.id} className="p-3 bg-green-50 rounded-md border border-green-200">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{userName || "Unknown"}</span>
                          <Badge variant="secondary" className="animate-pulse">Live</Badge>
                        </div>
                        <p className="text-sm text-gray-600">{surveyTitle || `Survey #${session.surveyId}`}</p>
                        <p className="text-sm text-gray-500">
                          Started: {new Date(session.startTime).toLocaleTimeString()}
                        </p>
                      </div>
                    ))}
                    {(!activeSessions || activeSessions.length === 0) && (
                      <p className="text-gray-500 text-center py-4">No active sessions</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* All Sessions for Review */}
              <Card>
                <CardHeader>
                  <CardTitle>Session Review</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {allSessions
                      ?.filter((s) => s.session.status === "submitted")
                      .map(({ session, userName }) => (
                        <div key={session.id} className="p-3 bg-orange-50 rounded-md border border-orange-200">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium">{userName || "Unknown"}</span>
                            <Badge variant="outline">Pending</Badge>
                          </div>
                          <p className="text-sm text-gray-600">
                            Duration: {Math.floor((session.duration || 0) / 60)}m | Active: {Math.floor((session.activeTime || 0) / 60)}m
                          </p>
                          <div className="flex gap-2 mt-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button size="sm" className="bg-green-500 hover:bg-green-600">
                                  <CheckCircle className="w-3 h-3 mr-1" /> Approve
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Approve Hours</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4 py-4">
                                  <div>
                                    <Label>Approved Hours</Label>
                                    <Input
                                      type="number"
                                      step="0.01"
                                      placeholder="Hours to approve"
                                      value={approveHours}
                                      onChange={(e) => setApproveHours(e.target.value)}
                                    />
                                    <p className="text-sm text-gray-500 mt-1">
                                      Active time: {(session.activeTime || 0) / 3600}h
                                    </p>
                                  </div>
                                  <Button
                                    className="w-full bg-green-500 hover:bg-green-600"
                                    onClick={() => {
                                      const hours = parseFloat(approveHours);
                                      if (isNaN(hours) || hours < 0) {
                                        toast.error("Invalid hours");
                                        return;
                                      }
                                      approveSession.mutate({ sessionId: session.id, approvedHours: hours });
                                      setApproveHours("");
                                    }}
                                  >
                                    Confirm Approval
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => rejectSession.mutate({ sessionId: session.id })}
                            >
                              <XCircle className="w-3 h-3 mr-1" /> Reject
                            </Button>
                          </div>
                        </div>
                      ))}
                    {(!allSessions || allSessions.filter((s) => s.session.status === "submitted").length === 0) && (
                      <p className="text-gray-500 text-center py-4">No pending sessions</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Payouts Tab */}
          <TabsContent value="payouts">
            <Card>
              <CardHeader>
                <CardTitle>Payout Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-3">User</th>
                        <th className="text-left py-2 px-3">Amount</th>
                        <th className="text-left py-2 px-3">Status</th>
                        <th className="text-left py-2 px-3">Date</th>
                        <th className="text-left py-2 px-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {allPayouts?.map(({ payout, userName }) => (
                        <tr key={payout.id} className="border-b hover:bg-gray-50">
                          <td className="py-2 px-3">{userName || "Unknown"}</td>
                          <td className="py-2 px-3">${Number(payout.amount).toFixed(2)}</td>
                          <td className="py-2 px-3">
                            <Badge
                              variant={
                                payout.status === "paid"
                                  ? "default"
                                  : payout.status === "approved"
                                  ? "secondary"
                                  : payout.status === "pending"
                                  ? "outline"
                                  : "destructive"
                              }
                            >
                              {payout.status}
                            </Badge>
                          </td>
                          <td className="py-2 px-3">
                            {payout.requestedAt ? new Date(payout.requestedAt).toLocaleDateString() : "-"}
                          </td>
                          <td className="py-2 px-3">
                            <div className="flex gap-1">
                              {payout.status === "pending" && (
                                <>
                                  <Button
                                    size="sm"
                                    className="bg-green-500 hover:bg-green-600"
                                    onClick={() => approvePayout.mutate({ payoutId: payout.id })}
                                  >
                                    Approve
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => rejectPayout.mutate({ payoutId: payout.id })}
                                  >
                                    Reject
                                  </Button>
                                </>
                              )}
                              {payout.status === "approved" && (
                                <Button
                                  size="sm"
                                  className="bg-[#FFD700] hover:bg-yellow-500 text-black"
                                  onClick={() => markPaid.mutate({ payoutId: payout.id })}
                                >
                                  Mark Paid
                                </Button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {(!allPayouts || allPayouts.length === 0) && (
                    <p className="text-gray-500 text-center py-4">No payout requests</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Surveys Tab */}
          <TabsContent value="surveys">
            <div className="grid lg:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Create Survey</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label>Title</Label>
                      <Input
                        placeholder="Survey title"
                        value={newSurveyTitle}
                        onChange={(e) => setNewSurveyTitle(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Description</Label>
                      <Input
                        placeholder="Survey description"
                        value={newSurveyDesc}
                        onChange={(e) => setNewSurveyDesc(e.target.value)}
                      />
                    </div>
                    <Button
                      className="bg-[#007BFF] hover:bg-blue-700"
                      onClick={() => {
                        if (!newSurveyTitle) {
                          toast.error("Title is required");
                          return;
                        }
                        createSurvey.mutate({ title: newSurveyTitle, description: newSurveyDesc });
                      }}
                      disabled={createSurvey.isPending}
                    >
                      {createSurvey.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <><Plus className="w-4 h-4 mr-2" /> Create Survey</>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Existing Surveys</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {surveys?.map((survey) => (
                      <div key={survey.id} className="p-3 bg-gray-50 rounded-md flex items-center justify-between">
                        <div>
                          <p className="font-medium">{survey.title}</p>
                          <p className="text-sm text-gray-600">{survey.description}</p>
                        </div>
                        <Badge variant={survey.isActive ? "default" : "outline"}>
                          {survey.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  System Settings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label>Hourly Rate ($)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        defaultValue={settings?.hourlyRate || "5.00"}
                        onBlur={(e) =>
                          updateSettings.mutate({ hourlyRate: parseFloat(e.target.value) })
                        }
                      />
                    </div>
                    <div>
                      <Label>Payout Threshold ($)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        defaultValue={settings?.payoutThreshold || "25.00"}
                        onBlur={(e) =>
                          updateSettings.mutate({ payoutThreshold: parseFloat(e.target.value) })
                        }
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label>Idle Timeout (seconds)</Label>
                      <Input
                        type="number"
                        defaultValue={settings?.idleTimeoutSeconds || 300}
                        onBlur={(e) =>
                          updateSettings.mutate({ idleTimeoutSeconds: parseInt(e.target.value) })
                        }
                      />
                    </div>
                    <div>
                      <Label>Max Daily Hours</Label>
                      <Input
                        type="number"
                        step="0.01"
                        defaultValue={settings?.maxDailyHours || "8.00"}
                        onBlur={(e) =>
                          updateSettings.mutate({ maxDailyHours: parseFloat(e.target.value) })
                        }
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
